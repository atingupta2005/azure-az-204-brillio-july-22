# Checkpointing

## 1
Reading data using group 1 and group 2 together


## 2
Reading data using group 1-app1 and group 1-app2 together
