# Scenarios
## 1
- Send data from partition 0 and receive data at partiotion 0

## 2
- Send data from partition 0 and receive data at partiotion 1

## 3
- Send data from partition all and receive data at partiotion 0 and at partiotion 1 both using 2 receivers

## 4
- Send data from partition all and receive data at partiotion all

## 5
- Send data from partition 1 and receive data at partiotion 1 - app1 and app2 both


## 5
- Send data from partition 0 and receive data at partiotion 0 - default and group1

